create definer = root@localhost trigger prevent_order
    before insert
    on shop
    for each row
BEGIN
    IF NEW.inventory < NEW.quantity_purchased THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '库存不足，无法下单';
    END IF;
END;

